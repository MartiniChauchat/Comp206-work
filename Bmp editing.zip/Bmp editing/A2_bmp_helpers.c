/* FILE: A2_bmp_helpers.c is where you will code your answers for Assignment 2.
 * 
 * Each of the functions below can be considered a start for you. 
 *
 * You should leave all of the code as is, except for what's surrounded
 * in comments like "REPLACE EVERTHING FROM HERE... TO HERE.
 *
 * The assignment document and the header A2_bmp_headers.h should help
 * to find out how to complete and test the functions. Good luck!
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <assert.h>

int bmp_open( char* bmp_filename,        unsigned int *width, 
              unsigned int *height,      unsigned int *bits_per_pixel, 
              unsigned int *padding,     unsigned int *data_size, 
              unsigned int *data_offset, unsigned char** img_data ){

              
  // YOUR CODE FOR Q1 SHOULD REPLACE EVERYTHING FROM HERE
    unsigned short bmType;
    unsigned short bmReserved1;
    unsigned short bmReserved2;
    unsigned int bmINFOHEADER;
    unsigned short bmPlanes;
    unsigned int bperline;
    FILE *fp = fopen(bmp_filename,"rb");
    if(fp==0)
    {
        printf("Cann't open the file!\n");
        return 1;
    }
    unsigned int size;
    fseek(fp,0,SEEK_SET);
    fseek(fp, 0, SEEK_END);
    size = (unsigned int)ftell(fp);
    rewind(fp);
    fread(&bmType,1,sizeof(unsigned short),fp);
    fread(data_size,1,sizeof(unsigned int),fp);
    fread(&bmReserved1,1,sizeof(unsigned short),fp);
    fread(&bmReserved2,1,sizeof(unsigned short),fp);
    fread(data_offset,1,sizeof(unsigned int),fp);
    fread(&bmINFOHEADER,1,sizeof(unsigned int),fp);
    fread(width,1,sizeof(unsigned int),fp);
    fread(height,1,sizeof(unsigned int),fp);
    fread(&bmPlanes,1,sizeof(unsigned short),fp);
    fread(bits_per_pixel,1,sizeof(unsigned short),fp);
    fseek(fp,0,SEEK_SET);
    *img_data = (unsigned char *)malloc(sizeof(unsigned char)*(*data_size));
    
    fread(*img_data,1,*data_size,fp);
    
    bperline = (*width* *bits_per_pixel)*4/32;
    if(bperline%4 !=0)
    {
        *padding = (bperline/4+1)*4-bperline;
    }
    else (*padding = 0);
    rewind(fp);
    fclose(fp);
  // TO HERE
  return 0;  
}

// We've implemented bmp_close for you. No need to modify this function
void bmp_close( unsigned char **img_data ){

  if( *img_data != NULL ){
    free( *img_data );
    *img_data = NULL;
  }
}

int bmp_mask( char* input_bmp_filename, char* output_bmp_filename, 
              unsigned int x_min, unsigned int y_min, unsigned int x_max, unsigned int y_max,
              unsigned char red, unsigned char green, unsigned char blue )
{
  unsigned int img_width;
  unsigned int img_height;
  unsigned int bits_per_pixel;
  unsigned int data_size;
  unsigned int padding;
  unsigned int data_offset;
  unsigned char* img_data    = NULL;
  
  int open_return_code = bmp_open( input_bmp_filename, &img_width, &img_height, &bits_per_pixel, &padding, &data_size, &data_offset, &img_data ); 
  
  if( open_return_code ){ printf( "bmp_open failed. Returning from bmp_mask without attempting changes.\n" ); return -1; }
 
  // YOUR CODE FOR Q2 SHOULD REPLACE EVERYTHING FROM HERE
    FILE *fpp;
    unsigned int num_colors = bits_per_pixel/8;
    unsigned int i,j;
    for(i=x_min;i<=x_max;i++){
        for(j=y_min;j<y_max;j++){
            img_data[i*(img_width*num_colors+padding)+j*num_colors+2+data_offset] = red;
            img_data[i*(img_width*num_colors+padding)+j*num_colors+1+data_offset] = green;
            img_data[i*(img_width*num_colors+padding)+j*num_colors+0+data_offset] = blue;
        }
    }
    if((fpp=fopen(output_bmp_filename,"wb"))==NULL)
    {
        printf("Cann't open the file!\n");
    }
    fseek(fpp,0,SEEK_SET);
    fwrite(img_data,sizeof(unsigned char),data_size,fpp);
    fclose(fpp);
  // TO HERE!
  
  bmp_close( &img_data );
  
  return 0;
}         

int bmp_collage( char* bmp_input1, char* bmp_input2, char* bmp_result, int x_offset, int y_offset ){

  unsigned int img_width1;
  unsigned int img_height1;
  unsigned int bits_per_pixel1;
  unsigned int data_size1;
  unsigned int padding1;
  unsigned int data_offset1;
  unsigned char* img_data1    = NULL;
  
  int open_return_code = bmp_open( bmp_input1, &img_width1, &img_height1, &bits_per_pixel1, &padding1, &data_size1, &data_offset1, &img_data1 ); 
  
  if( open_return_code ){ printf( "bmp_open failed for %s. Returning from bmp_collage without attempting changes.\n", bmp_input1 ); return -1; }
  
  unsigned int img_width2;
  unsigned int img_height2;
  unsigned int bits_per_pixel2;
  unsigned int data_size2;
  unsigned int padding2;
  unsigned int data_offset2;
  unsigned char* img_data2    = NULL;
  
  open_return_code = bmp_open( bmp_input2, &img_width2, &img_height2, &bits_per_pixel2, &padding2, &data_size2, &data_offset2, &img_data2 ); 
  
  if( open_return_code ){ printf( "bmp_open failed for %s. Returning from bmp_collage without attempting changes.\n", bmp_input2 ); return -1; }
  
  // YOUR CODE FOR Q3 SHOULD REPLACE EVERYTHING FROM HERE
    int result_width, result_height;
    
    unsigned int target_width = img_width2 + x_offset;
    unsigned int target_width2 = img_width1-x_offset;
    if(x_offset >= 0)
    {
        if(img_width1 > (target_width)){
            result_width = img_width1;
        }else{
            result_width = img_width2+x_offset;
        }
    }
    else{
        if(img_width2>(target_width2)){
            result_width = img_width2;
        }
        else
        {
            result_width = img_width1-x_offset;
        }
    }
    
    if(y_offset>=0){
        if(img_height1>(img_height2+y_offset)){
            result_height = img_height1;
        }else{
            result_height = img_height2+y_offset;
        }
    }
    else{
        if(img_height2>(img_height1-y_offset)){
            result_height = img_height2;
        }else{
            result_height = img_height1-y_offset;
        }
    }
    
    unsigned int new_padding = 0;
        while(((result_width*3 + new_padding)%4!=0))
        {
            (new_padding)++;
        }
    unsigned int result_data_size = (result_width+new_padding) * result_height * 3 + data_offset1;
    unsigned char* output_data = (unsigned char*)malloc((result_data_size)*sizeof(unsigned char));
    memcpy(output_data,img_data1,data_offset1);
    
    unsigned int num_colors = bits_per_pixel1/8;
    
    unsigned int img1_x_offset, img1_y_offset;
    
    *(unsigned int*)(output_data+2) = result_data_size;
    *(unsigned int*)(output_data+18) = result_width;
    *(unsigned int*)(output_data+22) = result_height;
    
    if(x_offset>0){
        img1_x_offset = 0;
    }else{
        img1_x_offset = -x_offset;
    }
    
    if(y_offset>0){
        img1_y_offset = 0;
    }else{
        img1_y_offset = -y_offset;
    }
    unsigned int m,p;
    for(m=img1_x_offset;m<img_width1+img1_x_offset;m++){
        for(p=img1_y_offset;p<img_height1+img1_y_offset;p++){
            for(int c=0;c<num_colors;c++){
                output_data[ p*(result_width*num_colors+new_padding) + m*num_colors + c +data_offset1 ] =
                img_data1[ (p-img1_y_offset)*(img_width1*num_colors+padding1) + (m-img1_x_offset)*num_colors + c +data_offset1 ];
            }
        }
    }
    
    unsigned int img2_x_offset, img2_y_offset;
    
    if(x_offset < 0){
        img2_x_offset = 0;
    }else{
        img2_x_offset = x_offset;
    }
    if(y_offset < 0){
        img2_y_offset = 0;
    }else{
        img2_y_offset = y_offset;
    }
    
    unsigned int i,j;
    for(i=img2_x_offset;i<(img2_x_offset+img_width2);i++){
        for(j=img2_y_offset;j<(img2_y_offset+img_height2);j++){
            for(int k=0;k<num_colors;k++){
                output_data[ j*(result_width*num_colors+new_padding) + i*num_colors + k +data_offset1 ] =
                img_data2[ (j-img2_y_offset)*(img_width2*num_colors+padding2) + (i-img2_x_offset)*num_colors + k +data_offset2 ];
                
            }
        }
    }
    FILE* fppp = fopen(bmp_result,"wb");
    fwrite(output_data,1,result_data_size,fppp);
    fclose(fppp);
    
  // TO HERE!
      
  bmp_close( &img_data1 );
  bmp_close( &img_data2 );
  
  return 0;
}                  
